package backend.user;

import java.util.List;
import backend.dog.Dog;
import backend.tag.Tag;

public class UserConfig {
	
private List<Tag> preferences;
	
	private String username;	
	private String email;	
	private String password;	
	private Wallet wallet;	
	private List<Dog> likedDogs;
	

	public List<Tag> getPreferences() {
		return preferences;
		
	}

	public void setPreferences(List<Tag> preferences) {
		
	}

	public String getUsername() {
		return email;
		
	}

	public void setUsername(String username) {
		
	}

	public String getEmail() {
		return email;
		
	}

	public void setEmail(String email) {
		
	}

	public String getPassword() {
		return password;
		
	}

	public void setPassword(String password) {
		
	}

	public Wallet getWallet() {
		return wallet;
		
	}

	public void setWallet(Wallet wallet) {

	}

	public List<Dog> getLikedDogs() {
		return null;
	
	}

	public void setLikedDogs(List<Dog> likedDogs) {
		
	}
	
	


}
